package com.example;

import java.math.BigDecimal;

public class Calculator {
    public double add(double a, double b) {
        return a + b;
    }

    public double subtract(double a, double b) {
        return a - b;
    }

    public static void main(String[] args) {
        System.out.println("Hello, Java is running!");
    }

    // public double multiply(double a, double b) {
    //     return a * b;
    // }

    public double divide(double a, double b) {
        if (b == 0)
            throw new ArithmeticException("division by zero");
        return a / b;
    }

    public double power(double a, int b) {
        if (b == 0)
            return 1.0;
        if (b < 0)
            return 1.0 / power(a, -b); // handle negative exponent properly
        double result = 1;
        for (int i = 1; i <= b; i++) {
            result *= a;
        }
        return result;
    }

    public double multiply(double a, double b) {
        // converting double to BigDecimal USING constructor is incorrect
        BigDecimal x = new BigDecimal(a); // BUG
        BigDecimal y = new BigDecimal(b); // BUG
        return x.multiply(y).doubleValue();
    }

}